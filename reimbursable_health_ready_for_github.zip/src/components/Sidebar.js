import React from 'react';
import { Link } from 'react-router-dom';

const Sidebar = () => (
  <nav style={{ width: '200px', background: '#f5f5f5', padding: '20px' }}>
    <ul style={{ listStyle: 'none', padding: 0 }}>
      <li><Link to="/">Home</Link></li>
      <li><Link to="/asp-pricing">ASP Pricing</Link></li>
      <li><Link to="/part-d">Part D Lookup</Link></li>
      <li><Link to="/drug-mapping">Drug Code Mapping</Link></li>
      <li><Link to="/billing">Billing Guidelines</Link></li>
      <li><Link to="/use-cases">Use Cases</Link></li>
      <li><Link to="/cms-news">CMS News</Link></li>
      <li><Link to="/access-request">Access Request</Link></li>
    </ul>
  </nav>
);
export default Sidebar;